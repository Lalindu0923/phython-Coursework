import tkinter as tk
from tkinter import ttk
import json

class FinanceTrackerGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Personal Finance Tracker")#title of the window
        root.geometry("800x600") #size of the window 
        self.create_widgets() #creating widgets for the user
        self.transactions = self.load_transactions("transactions.json") #load the json file
        self.detach_list = [] #list to store the deleted transactions when user search 
        
        

    def create_widgets(self):
       
         #creating widegets             
        
        
        self.frame_top = tk.Frame(self.root,bg="lightblue", borderwidth=1) #top frame for the search button and the serch entry 
        self.frame_top.pack(fill=tk.BOTH,padx=10,pady=20) #packing the top frame
        
        self.frame_mid = tk.Frame(self.root, relief=tk.SUNKEN,borderwidth=1,bg ="red") #middle frame for the treeview and the scrollbar
        self.frame_mid.pack(fill="both",expand="True")#packing the middle frame
        
        # Treeview for displaying transactions
        self.table = ttk.Treeview(self.frame_mid,columns=('category','date','type','amount'),show='headings') #create the treeview with the headings 
        self.table.heading('category',text = "Category",command=lambda: self.sort_by_column('category')) #create the headings category and the command with sort 
        self.table.heading('date',text = "Date",command=lambda: self.sort_by_column('date'))#create the headings date and the command with sort
        self.table.heading('type',text='description')#create the headings type,description of the transaction 
        self.table.heading('amount',text='Amount')#create the headings amount of the transaction
        self.table.pack(side='left',fill="both",expand="True")#packing the treeview

        
        
        # Scrollbar for the Treeview
        scrollbar = tk.Scrollbar(self.frame_mid,command=self.table.yview)
        self.table.configure(yscrollcommand=scrollbar.set) #configure the scrollbar with the treeview
        scrollbar.pack(side='right', padx=2, pady=4,fill="y")

         # Search bar and button
        self.entry = tk.Entry(self.frame_top,width=60)#create the entry bar for your to enter to search thye transaction
        self.entry.pack(side='left',padx=70,pady=15)#packing the entry bar
        button = ttk.Button(self.frame_top,text="Search",command=self.search_transactions)#create the search buttonFOR THE USER
        button.pack(side='right',padx=100,pady=10)#packing the search button
        

    def load_transactions(self, filename):
        try:
            with open (filename,"r") as file: #open the json file in read mode
                data = json.load(file)#load the json file as data
            return data
        except FileNotFoundError:#if the file is not found then return an empty dictionary
            return {}
        except json.JSONDecodeError:#if the file is not in json format then return an empty dictionary
            return {}

    def display_transactions(self, transactions):
         # Remove existing entries
        # Add transactions to the treeview
        if transactions:  # Check if transactions list is not empty
            for keys,values in transactions.items():#get the keys and values from the transactions
                #print(keys)
                #print(values)
                
                for transaction in values:#get the values from the values as transaction 
                    #print(transaction)
                    self.table.insert("", "end", values=( keys,transaction["date"],transaction["description"].upper(), transaction["amount"]))  # Insert transaction data into Treeview
                    
        else:  
            self.table.insert("", "end", values=("","No transactions found", "",""))  # Display a message if no transactions found
        

    def search_transactions(self):
       # Placeholder for search functionality
            
        search = self.entry.get().lower() #get the user input as a lowwercase
        
        if search:#check if the user input is not empty  
            for transaction in self.table.get_children():#for the transaction in the table 
                name = self.table.item(transaction)# get the all transaction from the table and store them in name  
                #print(name)
                search_list = [name["values"][0],name["values"][1].lower(),name["values"][2],str(name["values"][3])] #creat a search list with the values taken by the table 
                #print(search_list)
                if not search in search_list : #if user input name is not in the serch list the will get deleted 
                    self.table.delete(transaction)#delete the transaction if the user input is not in the search list
                    
                else:#if the user input is in the search list then the other transaction will be stored in the detach_list  
                    self.detach_list.append(transaction) #store other transaction in detach_list 
        else:#if the user input is empty then the transaction will be deleted from the table and the detach_list will be empty
            for transaction in self.detach_list :
                self.table.delete(transaction)
            self.display_transactions(self.transactions) 
    def sort_by_column(self, col, reverse=False):
        items = [(self.table.set(items,col),items) for items in self.table.get_children()] #
        
        #print(items)
        items.sort(reverse=reverse)
        #print(items)
        for  child in items:
            #print(val)
            
            self.table.move(child, '',"end")
            


def main():
    root = tk.Tk()#create the window
    app = FinanceTrackerGUI(root)#create the object of the class FinanceTrackerGUI
    app.display_transactions(app.transactions)#display the transactions in the table
    root.mainloop()#run the window

if __name__ == "__main__":
    main()
